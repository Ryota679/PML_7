const sdk = require('node-appwrite');

/*
  'req' variable has:
    'headers' - object with request headers
    'payload' - request body data as a string
    'variables' - object with function variables

  'res' variable has:
    'send(text, status)' - function to return text response. Status code defaults to 200
    'json(obj, status)' - function to return JSON response. Status code defaults to 200

  If an error is thrown, a response with code 500 will be returned.
*/

module.exports = async function (req, res) {
  const client = new sdk.Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(req.variables.APPWRITE_FUNCTION_API_KEY);

  const databases = new sdk.Databases(client);
  const users = new sdk.Users(client);

  try {
    // Parse request body
    const data = JSON.parse(req.payload || '{}');

    // Validate required fields
    const { email, password, full_name, username, phone, tenant_id, created_by, labels } = data;

    if (!email || !password || !full_name || !username || !tenant_id || !created_by) {
      return res.json({
        success: false,
        error: 'Missing required fields: email, password, full_name, username, tenant_id, created_by'
      }, 400);
    }

    // Validate labels if provided (should be array)
    const userLabels = labels && Array.isArray(labels) && labels.length > 0
      ? labels
      : ['tenant']; // Default label

    // Validate username format
    if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) {
      return res.json({
        success: false,
        error: 'Username must be at least 3 characters and contain only letters, numbers, and underscores'
      }, 400);
    }

    // Validate password length
    if (password.length < 8) {
      return res.json({
        success: false,
        error: 'Password must be at least 8 characters'
      }, 400);
    }

    console.log('Creating staff user:', { email, username, tenant_id });

    // Step 1: Check if username already exists
    try {
      const existingUsers = await databases.listDocuments(
        req.variables.DATABASE_ID,
        req.variables.USERS_COLLECTION_ID,
        [
          sdk.Query.equal('username', username)
        ]
      );

      if (existingUsers.total > 0) {
        return res.json({
          success: false,
          error: 'Username already exists'
        }, 409);
      }
    } catch (error) {
      console.error('Error checking username:', error);
    }

    // Step 2: Create user in Appwrite Auth
    let authUser;
    try {
      authUser = await users.create(
        sdk.ID.unique(),
        email,
        phone || undefined,
        password,
        full_name
      );
      console.log('Auth user created:', authUser.$id);
    } catch (error) {
      console.error('Error creating auth user:', error);
      return res.json({
        success: false,
        error: `Failed to create auth user: ${error.message}`
      }, 500);
    }

    // Step 3: Add labels to user (dynamic from input or default to 'tenant')
    try {
      await users.updateLabels(authUser.$id, userLabels);
      console.log('Labels added to user:', userLabels);
    } catch (error) {
      console.warn('Error adding labels (non-critical):', error);
    }

    // Step 4: Create user document in database
    try {
      const userDoc = await databases.createDocument(
        req.variables.DATABASE_ID,
        req.variables.USERS_COLLECTION_ID,
        sdk.ID.unique(),
        {
          user_id: authUser.$id,
          role: 'tenant',
          sub_role: 'staff',  // IMPORTANT: Mark as staff
          created_by: created_by,  // Track who created this user
          username: username,
          full_name: full_name,
          email: email,
          phone: phone || null,
          tenant_id: tenant_id,
          contract_end_date: null,  // Staff inherits tenant owner's contract
          is_active: true
        }
      );

      console.log('User document created:', userDoc.$id);

      return res.json({
        success: true,
        user_id: authUser.$id,
        document_id: userDoc.$id,
        message: 'Staff user created successfully'
      }, 201);

    } catch (error) {
      console.error('Error creating user document:', error);

      // Rollback: Delete auth user if document creation fails
      try {
        await users.delete(authUser.$id);
        console.log('Rolled back auth user creation');
      } catch (rollbackError) {
        console.error('Failed to rollback auth user:', rollbackError);
      }

      return res.json({
        success: false,
        error: `Failed to create user document: ${error.message}`
      }, 500);
    }

  } catch (error) {
    console.error('Unexpected error:', error);
    return res.json({
      success: false,
      error: error.message || 'Internal server error'
    }, 500);
  }
};
